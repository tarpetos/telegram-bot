from bot import MyBot


def main():
    custom_bot = MyBot()
    custom_bot.start()


if __name__ == "__main__":
    main()
