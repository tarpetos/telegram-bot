from random import choice


def get_random_data(data_arg):
    result = choice(data_arg)
    return result[0]
