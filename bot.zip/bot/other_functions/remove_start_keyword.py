def remove_mem_from_start(user_str: str) -> str:
    formatted_str = user_str[3:].strip()

    return formatted_str


def remove_rand_mem_from_start(user_str: str) -> str:
    formatted_str = user_str[10:].strip()

    return formatted_str
